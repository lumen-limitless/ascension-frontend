BY USING YOU AGREE THAT THE DEVELOPERS ARE NOT LIABLE FOR ANY FINANCIAL LOSS THAT RESULTS FROM USING THIS APPLICATION This is a simple command line mempool sniper that will automatically send a buy token transaction for you once it detects a pending add liquidity transaction for your target. The targets in settings can be a single or multiple addresses to improve chances of scoring a snipe. If the targets array in the settings file is blank, the sniper will attempt to snipe the first valid tokens it finds.
A couple things to keep in mind before using this program:
A valid private key to an account is required in order to submit transactions on your behalf. This key is only used for connection to the blockchain(same as Metamask etc.), stays on your device, and is not transmitted over the internet in any way. If you are not comfortable with this, do not use.
ALWAYS use a separate account created only for use with this program.
NEVER load the account with more than you can afford to lose.
This program is not a money printer, this is only a tool to help you buy tokens as quickly as possible. Research still needs to be done to ensure the tokens you are investing in are legit and not scams.
It is highly recommended to use very small amounts if you are running the program with no targets, most new tokens are scams and the liquidity may be pulled at any time.
You will most likely run into rate-limiting issues running the current version. Mempool sniping is VERY resource intensive and is only as effective as the provider it is connected to. Ascension Protocol may provide nodes to privileged members at a later time.
STEPS FOR USE:
1 - Create a new Ethereum address separate from your normal account(s). You can do this here(https://vanity-eth.tk/). This program requires a private key to submit transactions on your behalf. IT IS HIGHLY RECOMMENDED TO CREATE A NEW ACCOUNT AND ONLY USE IT FOR THIS PROGRAM. Revealing your private key in plain text can be dangerous. Only risk what you can afford to lose. Use the PRIVATE KEY from this new account for the settings file in the next step.
1.5 - this bot requires 80k ascend balance/votes in the account to function. You can delegate your ascend votes to your sniper account without actually transfering the tokens by going to https://arbiscan.io/address/0x9e724698051DA34994F281bD81C3E7372d1960AE#writeContract scroll down to delegate, enter the address of your sniper account, and click "write". You will need to connect with Metamask first by hitting the Connect to Web3 button at the top.
2 - remove ".example" from settings.example.json and edit the file adding in the data as required: privateKey: the PRIVATE KEY of the account you intend to use for sniping.
chainId: the chain ID number of the blockchain you wish to connect to. Currently supports 1(Ethereum) and 137(polygon)
targets: comma separated list of addresses for tokens you wish to snipe, surround each address with quotation marks ie. "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
amount: the amount of ether you wish to snipe with
gasMultiplier: the amount to multiply the target gas price with. Higher = faster transaction but more gas used
customProvider: you can add the WEBSOCKET URL for a custom provider to use here. Make sure the chainId matches the one you selected
3 - run the program "mempool-sniper-win.exe" (alternatively use the corresponding executable if you are on Linux or mac). ensure that a valid "settings.json" file is available in the same directory as the executable
4 - program will search for targets you specified, or if no targets are specified it will find the first liquidity transaction and attempt to snipe it with the amount you specified.
